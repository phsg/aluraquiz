module.exports = {
  images: {
    domains: [
      'assets.vercel.com',
      'api.screenshotmachine.com',
    ],
  },
};
